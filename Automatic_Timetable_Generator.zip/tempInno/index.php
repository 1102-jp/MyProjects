<?php
if (isset($_GET['generated']) && $_GET['generated'] == "false") {            //if programm is generated
    unset($_GET['generated']);
    echo '<script>alert("Timetable not generated yet!!");</script>';
}
?>
<!DOCTYPE html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>PROGRAM GENERATOR</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="./assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME CSS -->
    <link href="./assets/css/font-awesome.min.css" rel="stylesheet" />
    <!-- FLEXSLIDER CSS -->
    <link href="./assets/css/flexslider.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="./assets/css/style.css" rel="stylesheet" />


</head>

<body>
    <div class="navbar navbar-inverse navbar-fixed-top " id="menu">
        <div class="container">
            <div align="center">
                <h3 align="center">COMPUTER SCIENCE PROGRAM GENERATOR</h3>
            </div>
        </div>
    </div>

    <div class="carousel-inner">
        <div class="item active">
            <img src="assets/img/computer.jpg">
        </div>

        </script> <!--akuro -->
        <div align="center" STYLE="margin-top: 30px">
            <button data-scroll-reveal="enter from the bottom after 0.2s" id="teacherLoginBtn" class="btn btn-info btn-lg">TEACHER LOGIN
            </button>
            <button data-scroll-reveal="enter from the bottom after 0.2s" id="adminLoginBtn" class="btn btn-success btn-lg">ADMIN LOGIN
            </button>
        </div>
        <br>

        <div align="center">
            <form data-scroll-reveal="enter from the bottom after 0.2s" action="studentvalidation.php" method="post">
                <select id="select_semester" name="select_semester" class="list-group-item">
                    <option selected disabled>Select Semester</option>
                    <option value="3">2 Year ( Semester 3 )</option>
                    <option value="4">2 Year ( Semester 4 )</option>
                    <option value="5">3 Year ( Semester 5 )</option>
                    <option value="6">3 Year ( Semester 6 )</option>
                    <option value="7">4 Year ( Semester 7)</option>
                    <option value="8">4 Year ( Semester 8 )</option>
                </select>
                <button type="submit" class="btn btn-info btn-lg" style="margin-top: 10px">View</button> <!--view button-->
            </form>
        </div>
        <!-- The Modal -->
        </form>
        <div id="myModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
                <div class="modal-header">
                    <span class="close">&times</span>
                    <h2 id="popupHead">Modal Header</h2>
                </div>
                <div class="modal-body" id="LoginType">

                    <div style="display:none" id="adminForm"> <!--Admin Login Form-->
                        <form action="adminFormvalidation.php" method="POST">
                            <div class="form-group">
                                <label for="adminname">Username</label>
                                <input type="text" class="form-control" id="adminname" name="UN">
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="PASS">
                            </div>
                            <div align="right">
                                <input type="submit" class="btn btn-default" name="LOGIN" value="LOGIN">
                            </div>
                        </form>
                    </div>
                </div>

                <div style="display:none" id="facultyForm"> <!--Teacher Login Form-->
                    <form action="teacherform.php" method="POST" style="overflow: hidden">
                        <div class="form-group">
                            <label for="facultyno">Teacher's ID.</label>
                            <input type="text" class="form-control" id="facultyno" name="FN" placeholder="T...">
                        </div>
                        <div align="right">
                            <button type="submit" class="btn btn-default" name="LOGIN">LOGIN</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
            // Get the modal
            var modal = document.getElementById('myModal');

            // Get the button that opens the modal
            var teacherLoginBtn = document.getElementById("teacherLoginBtn");
            var adminLoginBtn = document.getElementById("adminLoginBtn");
            var heading = document.getElementById("popupHead");
            var facultyForm = document.getElementById("facultyForm");
            var adminForm = document.getElementById("adminForm");
            // Get the <span> element that closes the modal                                 //for the X
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks the button, open the modal
            adminLoginBtn.onclick = function() {
                modal.style.display = "block";
                heading.innerHTML = "Admin Login";
                adminForm.style.display = "block";
                facultyForm.style.display = "none";
            }
            teacherLoginBtn.onclick = function() {
                modal.style.display = "block";
                heading.innerHTML = "Faculty Login";
                facultyForm.style.display = "block";
                adminForm.style.display = "none";
            }
            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
                adminForm.style.display = "none";
                facultyForm.style.display = "none";
            }
        </script>

        <!--some scripts-->
        <script src="./assets/js/jquery-1.10.2.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <script src="./assets/js/jquery.flexslider.min.js"></script>
        <script src="./assets/js/scrollreveal.min.js"></script>
        <script src="./assets/js/jquery.easing.min.js"></script>
        <!-- <script src="./assets/js/custom.js"></script> -->


    </div>
</body>

</html>